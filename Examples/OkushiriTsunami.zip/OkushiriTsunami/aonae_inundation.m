clear all

fdir='Simulation/';
patt='AO';
nc=netcdf.open([fdir,patt,'_maxwave.nc'],'nowrite')
xx=netcdf.getVar(nc,0);
yy=netcdf.getVar(nc,1);
nx=length(xx)
ny=length(yy)
ha=double(netcdf.getVar(nc,2));
netcdf.close(nc)

bdir='OkushiriGrids/';
bpatt='AO15m_SSL2.1';
nc=netcdf.open([bdir,bpatt,'.nc'],'nowrite')
xx=netcdf.getVar(nc,0);
yy=netcdf.getVar(nc,1);
bb=double(netcdf.getVar(nc,2));
netcdf.close(nc)

figure
    ha(ha<-99999)=NaN;
    max(max(ha))
    min(min(ha))
    pcolor(xx,yy,ha')
    shading flat
    hold on
    [c,h]=contour(xx,yy,bb',[0.1 0.1],'color',[0 0 0],'linewidth',1.5);
    colorbar
    xlabel('^o E ','fontsize',14)
    ylabel('^o N ','fontsize',14)
    grid on
    box on

