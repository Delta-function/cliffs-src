%  Script to generate Fig.1 in Cliffs Manual:
%  simulation of a 0.0185d high solitary wave
%  runup onto a sloping beach 1:19.85,
%  numerics vs. analytics.
%  Inquiries to: e.tolkova@gmail.com

clear all

dirout='./';
casetitle='sol0185';  % read Cliffs output
nc=netcdf.open([dirout,casetitle,'_sea_h.nc'],'nowrite')
xx=netcdf.getVar(nc,0);
tt=netcdf.getVar(nc,2);
start=[0 0 0];
nx=length(xx)
nt=length(tt)
count=[nx 1 nt];
ha(1:nx,1:nt)=netcdf.getVar(nc,3,start,count);
netcdf.close(nc)
ha(ha<-9999)=NaN; % set to NaN over dry land

bpatt='slpbeach1D'; % read bathy file
nc=netcdf.open([dirout,bpatt,'.nc'],'nowrite')
bh(1:nx)=netcdf.getVar(nc,2);
netcdf.close(nc)

d=bh(nx);
tt=sqrt(9.81/d)*tt;  % dimesionless time

% analytical data with surface elevations at 35:05:70, dimensionless
[anx,b1,b2,b3,b4,b5,b6,b7,b8]=textread(['canonical_profiles.txt'],'%f %f %f %f %f %f %f %f %f %*[^\n]','emptyvalue',NaN);  
anh=[b2 b4 b6 b8];

figure
f(1)=axes('Position',[0.1 0.77 0.85 0.18],'box','on','fontsize',11);
f(2)=axes('Position',[0.1 0.54 0.85 0.18],'box','on','fontsize',11);
f(3)=axes('Position',[0.1 0.31 0.85 0.18],'box','on','fontsize',11);
f(4)=axes('Position',[0.1 0.08 0.85 0.18],'box','on','fontsize',11);

tt0=[40 50 60 70]; % profile times (dimensionless)

for i=1:4
    [terr,it]=min(abs(tt-tt0(i)));
    hh=ha(:,it);

    axes(f(i))
    hold on
    plot(anx,anh(:,i),'r','linewidth',1)
    plot(xx,-bh,'color',[0.4 0.4 0.4],'linewidth',2)
    plot(xx,hh,'xk','markersize',11)
    xlim([-2 16])
    ylim([-0.04 0.08])
    text(13, 0.05, int2str(tt0(i)),'fontsize',14)
    ylabel('\eta / d','fontsize',12)
    grid

end
xlabel('x / d','fontsize',12)

% keyboard
% 
%  fname = ['../../svn/Cliffs_new/TEX/Synolakis_profiles185'];
%  print ('-depsc','-r300', fname);
%  fname